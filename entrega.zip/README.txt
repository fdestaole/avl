Exercício 7 feito por:
João Pedro Farjoun Silva/13731319
Felipe Destaole/13686768
