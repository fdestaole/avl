#ifndef EX_7_UTIL_H
#define EX_7_UTIL_H

#include "avl.h"

char *readLine();
void adding_info(AVL* tree);

#endif //EX_7_UTIL_H
